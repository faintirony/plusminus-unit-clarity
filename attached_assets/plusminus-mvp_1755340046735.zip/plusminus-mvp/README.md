# ПлюсМинус MVP

SaaS платформа для автоматического мониторинга юнит-экономики селлеров маркетплейсов через интерактивные таблицы.

## 🎯 Обзор проекта

**ПлюсМинус** решает ключевую проблему селлеров на российских маркетплейсах - 95% из них не понимают свою реальную прибыльность. Платформа автоматически подключается к API Wildberries и OZON, рассчитывает юнит-экономику каждого товара и предоставляет интерактивные таблицы для анализа.

### Ключевые возможности

- 📊 **Автоматический расчет юнит-экономики** - маржа, ROI, прибыльность
- 🔄 **Синхронизация с маркетплейсами** - Wildberries и OZON API
- 📋 **Интерактивные таблицы** - фильтрация, поиск, сортировка
- 💾 **Управление себестоимостью** - inline редактирование
- 📈 **Анализ динамики** - исторические данные продаж
- 📑 **Экспорт данных** - Excel с сохранением форматирования
- 🔐 **Безопасность** - AES-256 шифрование API ключей

## 🏗 Архитектура

Проект построен на современном serverless стеке с разделением на фронтенд и бэкенд:

### Технологический стек

**Frontend:**
- Next.js 14 (App Router) + TypeScript
- TanStack Table для интерактивных таблиц
- React Query для управления состоянием
- Tailwind CSS + shadcn/ui
- Supabase Auth

**Backend:**
- Next.js API Routes (Edge Functions)
- Supabase PostgreSQL
- Background Jobs для синхронизации
- Redis для кэширования

**Инфраструктура:**
- Vercel (полный проект: фронтенд + API routes)
- Supabase (база данных + Auth)
- Upstash (Redis для кэширования)

## 📁 Структура проекта

```
plusminus-mvp/
├── ARCHITECTURE.md          # Техническая архитектура
├── plusminus-prd-v1.md     # Product Requirements Document
│
├── app/                     # Next.js App Router
│   ├── layout.tsx          # [FRONTEND] Root layout
│   ├── page.tsx            # [FRONTEND] Landing page
│   ├── globals.css         # [FRONTEND] Стили
│   └── api/                # [BACKEND] API endpoints
│       ├── auth/           # Аутентификация
│       ├── users/          # Пользователи
│       ├── products/       # Товары
│       ├── sync/           # Синхронизация
│       └── exports/        # Экспорт данных
│
├── components/             # [FRONTEND] React компоненты
├── hooks/                  # [FRONTEND] React hooks
├── lib/                    # Утилиты и сервисы
│   ├── supabase.ts        # Supabase клиент
│   ├── server/            # [BACKEND] Серверные утилиты
│   ├── marketplaces/      # [BACKEND] Интеграции с API
│   └── jobs/              # [BACKEND] Background jobs
│
├── types/                  # TypeScript типы
├── supabase/              # [BACKEND] Схема БД
├── docs/                   # Документация
└── public/                # [FRONTEND] Статические файлы
```

## 🚀 Быстрый старт

### Предварительные требования

- Node.js 18+
- Supabase проект
- API ключи маркетплейсов (для тестирования)

### Установка

1. **Клонировать репозиторий:**
```bash
git clone <repository-url>
cd plusminus-mvp
```

2. **Установить зависимости:**
```bash
npm install
```

3. **Настроить переменные окружения:**
```bash
cp .env.local.example .env.local
# Заполните переменные в .env.local
```

4. **Настроить Supabase:**
```bash
# Создать таблицы в Supabase
psql -d your_database -f supabase/schema.sql
```

5. **Запустить проект:**
```bash
npm run dev
```

## 🔧 Процесс разработки

Согласно PRD, используется **единая Next.js архитектура** на Vercel:

### Этап 1: Разработка API (Claude Code)
Быстрая разработка серверной логики с AI помощью

### Этап 2: Перенос в Replit
Объединение фронтенда и готового API в единый проект

### Этап 3: Деплой на Vercel
Serverless деплой полного приложения

Подробный план в [docs/DEPLOYMENT_SPLIT.md](docs/DEPLOYMENT_SPLIT.md)

## 📊 База данных

Использует Supabase PostgreSQL с оптимизацией для больших каталогов:

### Ключевые таблицы
- `users` - Пользователи системы
- `marketplace_credentials` - Зашифрованные API ключи
- `products` - Товары с рассчитанными метриками
- `sales_data` - Исторические данные продаж
- `sync_logs` - Логи синхронизации

### Производительность
- Индексы для быстрого поиска по маржинальности
- Generated columns для автоматического расчета метрик
- Row Level Security (RLS) для безопасности
- Партиционирование для больших объемов данных

## 🔌 API

REST API с JWT аутентификацией через Supabase.

### Основные endpoints:
- `GET /api/products` - Список товаров с фильтрацией
- `POST /api/sync/start` - Запуск синхронизации
- `POST /api/exports/excel` - Экспорт в Excel
- `GET /api/users/metrics` - Метрики пользователя

Полная документация в [docs/API.md](docs/API.md)

## 🔐 Безопасность

- **Шифрование:** AES-256 для API ключей, TLS 1.3 для передачи
- **Аутентификация:** Supabase JWT токены
- **Авторизация:** Row Level Security (RLS)
- **Соответствие 152-ФЗ:** Локализация данных в РФ
- **Rate Limiting:** 100 запросов/минуту на пользователя

## 📈 Масштабируемость

- **Поддержка:** до 50,000 SKU на аккаунт
- **Пользователи:** до 10,000 одновременных
- **Производительность:** загрузка таблицы < 2 секунд
- **Кэширование:** Redis для часто запрашиваемых данных

## 🧪 Тестирование

```bash
# Unit тесты
npm run test

# Типы
npm run type-check

# Линтинг
npm run lint
```

## 📦 Деплой

### На Vercel
```bash
vercel --prod
```

## 📚 Документация

- [ARCHITECTURE.md](ARCHITECTURE.md) - Техническая архитектура
- [docs/API.md](docs/API.md) - API документация
- [docs/DEPLOYMENT_SPLIT.md](docs/DEPLOYMENT_SPLIT.md) - План разделения проекта
- [plusminus-prd-v1.md](plusminus-prd-v1.md) - Продуктовые требования

## 🎯 Roadmap MVP

- [x] ✅ Создание архитектуры и структуры проекта
- [x] ✅ Схема базы данных с Supabase
- [x] ✅ API спецификации и документация
- [ ] 🔄 Реализация API endpoints
- [ ] ⏳ Интеграция с Wildberries API
- [ ] ⏳ Интеграция с OZON API
- [ ] ⏳ Разработка UI компонентов
- [ ] ⏳ Интерактивные таблицы с TanStack Table
- [ ] ⏳ Система экспорта в Excel
- [ ] ⏳ Background jobs для синхронизации
- [ ] ⏳ Тестирование и деплой

## 🤝 Контрибьюция

1. Fork репозитория
2. Создать feature branch
3. Сделать изменения
4. Написать тесты
5. Создать Pull Request

## 📄 Лицензия

MIT License - см. [LICENSE](LICENSE) файл.

---

**ПлюсМинус** - делаем прибыльность селлеров видимой и управляемой! 📊💰