# ПлюсМинус API Документация

## Обзор

REST API для SaaS платформы мониторинга юнит-экономики селлеров маркетплейсов.

**Base URL:** `https://your-domain.com/api`  
**Authentication:** Bearer Token (Supabase JWT)

## Аутентификация

Все API запросы требуют аутентификации через Supabase JWT токен в заголовке:

```
Authorization: Bearer <supabase_jwt_token>
```

---

## Endpoints

### 🔐 Authentication

#### POST /api/auth/register
Регистрация нового пользователя

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "Имя Пользователя"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "name": "Имя Пользователя"
    },
    "session": {
      "access_token": "jwt_token",
      "refresh_token": "refresh_token"
    }
  }
}
```

#### POST /api/auth/login
Вход в систему

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

---

### 👤 Users

#### GET /api/users/profile
Получить профиль текущего пользователя

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "Имя Пользователя",
    "isActive": true,
    "createdAt": "2024-01-01T00:00:00Z",
    "updatedAt": "2024-01-01T00:00:00Z"
  }
}
```

#### PUT /api/users/profile
Обновить профиль

**Request Body:**
```json
{
  "name": "Новое Имя"
}
```

#### GET /api/users/metrics
Получить общие метрики пользователя

**Response:**
```json
{
  "success": true,
  "data": {
    "totalProducts": 150,
    "profitableProducts": 120,
    "unprofitableProducts": 30,
    "avgMarginPercent": 18.5,
    "totalRevenueToday": 45000
  }
}
```

---

### 🔑 Marketplace Credentials

#### GET /api/credentials
Получить список подключенных маркетплейсов

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "marketplace": "wildberries",
      "isValid": true,
      "lastValidatedAt": "2024-01-01T00:00:00Z"
    },
    {
      "id": "uuid",
      "marketplace": "ozon",
      "isValid": false,
      "lastValidatedAt": null
    }
  ]
}
```

#### POST /api/credentials
Добавить API ключ маркетплейса

**Request Body:**
```json
{
  "marketplace": "wildberries",
  "apiKey": "your_api_key_here"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "marketplace": "wildberries",
    "isValid": true,
    "message": "API ключ успешно добавлен и проверен"
  }
}
```

#### DELETE /api/credentials/[id]
Удалить API ключ

---

### 📦 Products

#### GET /api/products
Получить список товаров с фильтрацией

**Query Parameters:**
- `page` (number): Номер страницы (по умолчанию 1)
- `limit` (number): Количество на странице (по умолчанию 50, максимум 1000)
- `search` (string): Поиск по названию или SKU
- `marketplace` (string): Фильтр по маркетплейсу (`wildberries`, `ozon`)
- `minMargin` (number): Минимальная маржа в %
- `maxMargin` (number): Максимальная маржа в %
- `onlyUnprofitable` (boolean): Только убыточные товары
- `sortBy` (string): Поле сортировки (`marginPercent`, `name`, `currentPrice`)
- `sortOrder` (string): Порядок сортировки (`asc`, `desc`)

**Example Request:**
```
GET /api/products?search=кроссовки&marketplace=wildberries&minMargin=0&sortBy=marginPercent&sortOrder=desc&page=1&limit=50
```

**Response:**
```json
{
  "success": true,
  "data": {
    "products": [
      {
        "id": "uuid",
        "sku": "123456789",
        "name": "Кроссовки Nike Air Max",
        "marketplace": "wildberries",
        "currentPrice": 5990,
        "costPrice": 3500,
        "commission": 899,
        "logisticsCost": 200,
        "advertisingCost": 150,
        "marginRub": 1241,
        "marginPercent": 20.72,
        "isProfitable": true,
        "isActive": true,
        "lastSyncedAt": "2024-01-01T00:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 50,
      "total": 150,
      "totalPages": 3
    }
  }
}
```

#### GET /api/products/[id]
Получить детали товара

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "sku": "123456789",
    "name": "Кроссовки Nike Air Max",
    "marketplace": "wildberries",
    "currentPrice": 5990,
    "costPrice": 3500,
    "commission": 899,
    "logisticsCost": 200,
    "advertisingCost": 150,
    "marginRub": 1241,
    "marginPercent": 20.72,
    "isProfitable": true,
    "salesHistory": [
      {
        "date": "2024-01-01",
        "revenue": 11980,
        "quantity": 2,
        "returns": 0,
        "adSpend": 300
      }
    ]
  }
}
```

#### PUT /api/products/[id]/cost
Обновить себестоимость товара

**Request Body:**
```json
{
  "costPrice": 3200
}
```

#### PUT /api/products/[id]
Обновить товар

**Request Body:**
```json
{
  "costPrice": 3200,
  "isActive": false
}
```

---

### 🔄 Synchronization

#### POST /api/sync/start
Запустить синхронизацию данных

**Request Body:**
```json
{
  "marketplace": "wildberries" // опционально, если не указано - все маркетплейсы
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "syncId": "uuid",
    "status": "pending",
    "message": "Синхронизация запущена"
  }
}
```

#### GET /api/sync/status/[syncId]
Получить статус синхронизации

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "status": "running",
    "marketplace": "wildberries",
    "startedAt": "2024-01-01T00:00:00Z",
    "completedAt": null,
    "productsSynced": 45,
    "totalProducts": 150,
    "progress": 30
  }
}
```

#### GET /api/sync/logs
Получить историю синхронизаций

**Query Parameters:**
- `page` (number): Номер страницы
- `limit` (number): Количество записей
- `marketplace` (string): Фильтр по маркетплейсу

**Response:**
```json
{
  "success": true,
  "data": {
    "logs": [
      {
        "id": "uuid",
        "marketplace": "wildberries",
        "status": "completed",
        "startedAt": "2024-01-01T00:00:00Z",
        "completedAt": "2024-01-01T00:05:00Z",
        "productsSynced": 150,
        "errorMessage": null
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 50,
      "totalPages": 3
    }
  }
}
```

---

### 📊 Exports

#### POST /api/exports/excel
Экспортировать данные в Excel

**Request Body:**
```json
{
  "filters": {
    "search": "кроссовки",
    "marketplace": "wildberries",
    "minMargin": 0
  },
  "columns": ["sku", "name", "marginPercent", "currentPrice"],
  "includeHistory": false
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "downloadUrl": "https://temp-storage/export_123.xlsx",
    "expiresAt": "2024-01-01T01:00:00Z"
  }
}
```

---

### 🔍 Filter Presets

#### GET /api/filters
Получить сохраненные фильтры

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "name": "Убыточные товары",
      "filters": {
        "onlyUnprofitable": true
      },
      "isDefault": false
    }
  ]
}
```

#### POST /api/filters
Сохранить фильтр

**Request Body:**
```json
{
  "name": "Высокомаржинальные",
  "filters": {
    "minMargin": 20
  },
  "isDefault": false
}
```

#### PUT /api/filters/[id]
Обновить фильтр

#### DELETE /api/filters/[id]
Удалить фильтр

---

### 🎯 Webhooks (для внешних интеграций)

#### POST /api/webhooks/marketplace
Webhook для получения данных от маркетплейсов

**Headers:**
```
X-Webhook-Signature: signature
Content-Type: application/json
```

---

## Коды ответов

- `200` - Успешно
- `201` - Создано
- `400` - Ошибка валидации
- `401` - Не авторизован
- `403` - Доступ запрещен
- `404` - Не найдено
- `429` - Превышен лимит запросов
- `500` - Внутренняя ошибка сервера

## Формат ошибок

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Описание ошибки",
    "details": {
      "field": "email",
      "issue": "Некорректный формат email"
    }
  }
}
```

## Rate Limiting

- **Общие запросы:** 100 запросов в минуту на пользователя
- **Синхронизация:** 1 запрос в 5 минут на пользователя
- **Экспорт:** 5 запросов в час на пользователя

## Webhooks Events

При изменении данных система может отправлять webhooks:

- `product.margin_changed` - Изменилась маржинальность товара
- `sync.completed` - Завершена синхронизация
- `sync.failed` - Ошибка синхронизации